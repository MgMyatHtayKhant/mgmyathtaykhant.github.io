import csv
from sys import argv, exit


# Define main


def main():
    # Check user input
    if len(argv) != 3:
        exit("Usage: python dna.py data.csv sequence.txt")

    # Open the csv file and dna sequence and read contents into memory
    csv_file = open(argv[1], "r")
    reader = csv.reader(csv_file)
    keys = next(reader)[1:]

    with open(argv[2], "r") as txt_file:
        sequence_txt = txt_file.read().rstrip()

    counts = str_count(keys, sequence_txt, consecutive_repeats)

    # Match between csv dna database and txt dna sequence
    match(reader, counts)
    csv_file.close()


# Define STR count


def str_count(keys, sequence, f):
    counts = list()
    for key in keys:
        tmp = [0]
        length_key = len(key)
        for start in range(len(sequence) - length_key + 1):
            end = length_key + start
            count = f(start, end, key, sequence, length_key)
            tmp.append(count)
        counts.append(str(max(tmp)))
    return counts


# Define consecutive repeats of the STR


def consecutive_repeats(start, stop, key, sequence, length_key):
    if key == sequence[start:stop]:
        return 1 + consecutive_repeats(stop, stop + length_key, key, sequence, length_key)
    return 0


# Define match


def match(reader, counts):
    for row in reader:
        if row[1:] == counts:
            print(row[0])
            break
    else:
        print("No match")


# Check special variable run like main program
if __name__ == "__main__":
    main()