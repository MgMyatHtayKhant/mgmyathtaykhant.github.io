#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

//Size of 1 byte and 512 byte
const int FILE_SIZE = 512;
typedef uint8_t Byte;

int main(int argc, char *argv[])
{
    //Checking for one argument
    if (argc != 2)
    {
        printf("Usage: ./recover argument\n");
        return 1;
    }
    
    //Open memory card
    FILE *file = fopen(argv[1], "r");
    if (!file)
    {
        printf("Can't open %s\n", argv[1]);
        return 1;
    }
    
    Byte buffer[FILE_SIZE];
    char name[10]; 
    int i = -1;
    int count = 0;
    FILE *image = NULL;
    
    
    
    //Look for beginning of a JPEG
    while (fread(buffer, FILE_SIZE, 1, file))
    {
        //Checking JPEG or not
        if (buffer[0] == 0xff && buffer[1] == 0xd8 && buffer[2] == 0xff && (buffer[3] & 0xf0) == 0xe0)
        {
            i++;        
            if (i != 0)
            {
                fclose(image);
            }
            
            sprintf(name, "%03i.jpg", i);
            image = fopen(name, "w");
            fwrite(buffer, FILE_SIZE, 1, image);
            count = i;
            
        }
        else
        {
            if (count == i)
            {
                fwrite(buffer, FILE_SIZE, 1, image);
            }
        }
    }
    
    //Close files
    fclose(image);
    fclose(file);
    return 0;
}