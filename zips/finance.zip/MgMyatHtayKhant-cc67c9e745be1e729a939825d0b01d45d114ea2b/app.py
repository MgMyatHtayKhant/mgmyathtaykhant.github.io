from http.client import responses
import os
from urllib import response

from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, lookup, usd, companyName

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True


# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


# Custom filter
app.jinja_env.filters["usd"] = usd
app.jinja_env.filters["companyName"] = companyName

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite datasbase
db = SQL("sqlite:///finance.db")

# Make sure API key is set
if not os.environ.get("API_KEY"):
    raise RuntimeError("API_KEY not set")


@app.route("/")
@login_required
def index():
    """Show portfolio of stocks"""

    try:
        users = db.execute("SELECT cash FROM users WHERE id = ?", session['user_id'])
        rows = db.execute("SELECT min(shares), symbol FROM history WHERE user_id = ? GROUP BY symbol", session['user_id'])
    except:
        datas = []

    else:
        if rows:
            datas = []
            for each in rows:
                shares = each['min(shares)']
                if shares == 0:
                    continue
                data = lookup(each['symbol'])
                data['shares'] = shares
                data['total'] = shares * data['price']
                datas.append(data)
        else:
            datas = []

    return render_template('index.html', datas=datas, cash=users[0]['cash'])


@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    """Buy shares of stock"""
    if request.method == "POST":
        stock_symbol = request.form.get('symbol')  # stock symbol
        shares = request.form.get('shares')  # shares number
        response = lookup(stock_symbol)  # return stock symbol name, price and symbol as dict

        if not stock_symbol:
            return apology('The input symbol is blank.')
        elif not response:
            return apology('The symbol does not exist.')
        elif not shares:
            return apology('The input share is blank.')

        user = db.execute('SELECT * FROM users WHERE id = ?', session['user_id'])
        user_cash = user[0]['cash']

        try:
            shares = int(shares)
        except:
            return apology('Input Error!')

        if shares <= 0:
            return apology('At least 1 share is minimum to buy!')

        total = shares * response['price']

        if total > user_cash:
            return apology("You don't have enough cash.")
        else:
            user_cash = user_cash - total
            db.execute('UPDATE users SET cash = ? WHERE id = ?',  user_cash, session['user_id'])

            user = db.execute('SELECT * FROM users WHERE id = ?', session['user_id'])
            user_cash = user[0]['cash']

            try:
                db.execute("CREATE TABLE history (user_id INTEGER, symbol TEXT, shares NUMERIC,  price NUMERIC, record_shares NUMERIC, transacted TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users (id))")
            except:
                pass
            else:
                pass
            finally:
                db.execute("INSERT INTO history (user_id, symbol, shares, price, record_shares) VALUES(?,?,?,?,?)",
                           session['user_id'], response['symbol'], shares, response['price'], shares)
            flash("Bought!")
            return redirect('/')
    else:
        return render_template('buy.html')


@app.route("/history")
@login_required
def history():
    """Show history of transactions"""
    rows = db.execute("SELECT * FROM history WHERE user_id = ?", session['user_id'])
    return render_template('history.html', rows=rows)


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 400)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 400)

        # Query datasbase for username
        rows = db.execute("SELECT * FROM users WHERE username = ?", request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 400)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page

        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    """Get stock quote."""
    if request.method == "POST":
        stock_symbol = request.form.get('symbol')
        response = lookup(stock_symbol)
        if not response:
            return apology('The stock did not actually exist.')
        response['name'] = ", ".join(response['name'].split())
        return render_template('quoted.html', response=response)
    else:
        return render_template('quote.html')


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        name = request.form.get('username')
        password = request.form.get('password')
        confirmation = request.form.get('confirmation')
        rows = db.execute("SELECT * FROM users WHERE username = ?", name)
        hash_password = generate_password_hash(password)

        if not name:
            return apology("Must provide user name", 400)
        elif len(rows) != 0:
            return apology("The username already exists", 400)
        elif not password:
            return apology("Must provide user password", 400)
        elif password != confirmation:
            return apology("The passowrd do not match", 400)
        session["user_id"] = db.execute('INSERT INTO users (username, hash) VALUES(?, ?)', name, hash_password)
        flash('Registered!')
        return redirect('/')
    else:
        return render_template('register.html')


@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """Sell shares of stock"""

    if request.method == "POST":

        if not request.form.get('symbol'):
            return apology('Select a stock!')

        sell_shares = request.form.get('shares')

        if not sell_shares:
            return apology('The input share is blank.')

        rows = db.execute("SELECT symbol, shares FROM history WHERE user_id = ? AND symbol = ?",
                          session['user_id'], request.form.get('symbol'))
        own_shares = rows[-1]['shares']
        symbol = rows[-1]['symbol']

        sell_shares = int(sell_shares)

        if sell_shares > own_shares:
            return apology('You does not own that many shares of the stock')

        response = lookup(symbol)
        current_shares = own_shares - sell_shares
        sell_shares_prices = sell_shares * response['price']
        users = db.execute("SELECT cash FROM users WHERE id = ?", session['user_id'])
        total_cash = sell_shares_prices + users[0]['cash']
        db.execute("UPDATE users SET cash = ? WHERE id = ?", total_cash, session['user_id'])
        db.execute("INSERT INTO history (user_id, symbol, shares, price, record_shares) VALUES(?,?,?,?,?)",
                   session['user_id'], symbol, current_shares, response['price'], sell_shares * (-1))
        flash("Sold!")
        return redirect('/')
    else:
        rows = db.execute(
            "SELECT min(shares) AS share, symbol FROM history WHERE user_id = ? GROUP BY symbol HAVING share > 0", session['user_id'])
        return render_template('sell.html', rows=rows)


def errorhandler(e):
    """Handle error"""
    if not isinstance(e, HTTPException):
        e = InternalServerError()
    return apology(e.name, e.code)


# Listen for errors
for code in default_exceptions:
    app.errorhandler(code)(errorhandler)
