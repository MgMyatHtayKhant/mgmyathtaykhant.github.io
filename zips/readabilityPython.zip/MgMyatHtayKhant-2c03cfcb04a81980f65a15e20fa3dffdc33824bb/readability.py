# Define main


def main():
    text = input("Text: ")
    words = len(text.split())
    letters, sentences = letter_sentences(text)
    index = coleman_liau(letters, sentences, words)
    grade(index)

# Define letter and sentences


def letter_sentences(text):
    l = s = 0
    for each in text:
        if each.isalpha():
            l += 1
        elif each in ["!", ".", "?"]:
            s += 1
    return (l, s)


# Define Coleman_liau index


def coleman_liau(letters, sentences, words):
    one_hundred = 100
    letters = (one_hundred/words) * letters
    sentences = (one_hundred/words) * sentences
    return round(0.0588 * letters - 0.296 * sentences - 15.8)


# Define grade


def grade(index):
    if index >= 16:
        print("Grade 16+")
    elif index < 1:
        print("Before Grade 1")
    else:
        print(f"Grade {index}")


# Check special variable run like main program
if __name__ == "__main__":
    main()