//Image Slide
var slideIndex = 0;
var stop_now = null;

showSlides();

function showSlides() {
  var slides = document.querySelectorAll(".mySlides");
  var length = slides.length;
  if (length === 0) {
    return;
  }
  for (let i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length) {
    slideIndex = 1;
  }
  slides[slideIndex - 1].style.display = "block";

  stop_now = window.setTimeout(showSlides, 3000);
}

//Thank CS50
callThankYou();

function callThankYou() {
  var boxes = document.querySelectorAll(".box");
  var drop_box = document.querySelector("#drop-box");
  if (drop_box === null) {
    return;
  }
  var box = drop_box.value;
  boxes[parseInt(box)].style.display = "flex";

  document.querySelector("#cs50").addEventListener("click", function () {
    for (let i = 0; i < boxes.length; i++) {
      boxes[i].style.display = "none";
    }
    box = drop_box.value;
    boxes[parseInt(box)].style.display = "flex";
  });
}
