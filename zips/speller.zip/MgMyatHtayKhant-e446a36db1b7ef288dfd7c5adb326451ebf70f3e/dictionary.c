// Implements a dictionary's functionality
#include "dictionary.h"
#include <stdio.h>
#include <math.h>
#include <ctype.h>
#include <stdlib.h>
#include <strings.h>
#include <string.h>

// Represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
}
node;

// Number of buckets in hash table
const unsigned int N = 456976;

// Hash table
node *table[N];

//Numbers of words in hash table
int numbers_in_hash = 0;

// Returns true if word is in dictionary, else false
bool check(const char *word)
{
    // TODO
    int index = hash(word);
    for (node *tmp = table[index]; tmp != NULL; tmp = tmp->next)
    {
        if (strcasecmp(word, tmp->word) == 0)
        {
            return true;
        }
    }
    return false;
}

// Hashes word to a number
unsigned int hash(const char *word)
{
    // TODO
    // My own hash function
    int sum = 0;
    int length = strlen(word);
    int n = (length > 4) ? 4 : length;
    for (int i = 0; i < n; i++)
    {
        char c = tolower(word[i]);
        sum += ((c - 'a') * pow(26, n - 1 - i));
    }
    return sum % N;
}

// Loads dictionary into memory, returning true if successful, else false
bool load(const char *dictionary)
{
    // TODO
    // Open the dictionary file with read mode
    FILE *file = fopen(dictionary, "r");
    if (file == NULL)
    {
        return false;
    }

    // Read words from dictionary file
    char words[LENGTH + 1];
    while (fscanf(file, "%s", words) != EOF)
    {
        node *n = malloc(sizeof(node));
        if (n == NULL)
        {
            return false;
        } //Copy each words from words array to node word
        strcpy(n->word, words);

        //Size
        numbers_in_hash++;

        //Call hash function for each node and then insert it in hash table
        int index = hash(words);
        n->next = table[index];
        table[index] = n;
    }

    //Close file
    fclose(file);
    return true;
}

// Returns number of words in dictionary if loaded, else 0 if not yet loaded
unsigned int size(void)
{
    // TODO
    return numbers_in_hash;
}

// Unloads dictionary from memory, returning true if successful, else false
bool unload(void)
{
    // TODO
    for (int i = 0; i < N; i++)
    {
        while (table[i] != NULL)
        {
            node *tmp = table[i]->next;
            free(table[i]);
            table[i] = tmp;
        }
    }
    return true;
}