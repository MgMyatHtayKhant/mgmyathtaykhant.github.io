#include "helpers.h"
#include <math.h>

//Prototype
RGBTRIPLE box_blur(int r, int c, int height, int width, RGBTRIPLE image[height][width]);

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            int average = round((image[i][j].rgbtBlue + image[i][j].rgbtGreen + image[i][j].rgbtRed) / (float)sizeof(RGBTRIPLE));
            image[i][j].rgbtBlue = average;
            image[i][j].rgbtGreen = average;
            image[i][j].rgbtRed = average;
        }
    }
    return;
}

// Convert image to sepia
void sepia(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            //sepia version of the pixel
            int sepiaRed = round((0.393 * image[i][j].rgbtRed) + (0.769 * image[i][j].rgbtGreen) + (0.189 * image[i][j].rgbtBlue));
            int sepiaGreen = round((0.349 * image[i][j].rgbtRed) + (0.686 * image[i][j].rgbtGreen) + (0.168 * image[i][j].rgbtBlue));
            int sepiaBlue = round((0.272 * image[i][j].rgbtRed) + (0.534 * image[i][j].rgbtGreen) + (0.131 * image[i][j].rgbtBlue));

            //Check 0 - 255
            image[i][j].rgbtRed = (sepiaRed > 255) ? 255 : sepiaRed;
            image[i][j].rgbtGreen = (sepiaGreen > 255) ? 255 : sepiaGreen;
            image[i][j].rgbtBlue = (sepiaBlue > 255) ? 255 : sepiaBlue;
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width / 2; j++)
        {
            RGBTRIPLE pixel = image[i][j];
            image[i][j] = image[i][width - 1 - j];
            image[i][width - 1 - j] = pixel;
        }
    }
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    //second image
    RGBTRIPLE new_image[height][width];
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            new_image[i][j] = box_blur(i, j, height, width, image);
        }
    }

    //Copying blur pixels from second image to original image
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            image[i][j] = new_image[i][j];
        }
    }
    return;
}

//Kernel convolution
RGBTRIPLE box_blur(int r, int c, int height, int width, RGBTRIPLE image[height][width])
{
    // 3 x 3 kernel
    int length = 3;
    int row[] = {r - 1, r, r + 1};
    int colum[] = {c - 1, c, c + 1};

    RGBTRIPLE pixel;
    int sum_red = 0;
    int sum_green = 0;
    int sum_blue = 0;
    float count = 0;

    //Checking kernel is in between image rows and cloums
    for (int i = 0; i < length; i++)
    {
        if (row[i] > -1 && row[i] < height)
        {
            for (int j = 0; j < length; j++)
            {
                if (colum[j] > - 1 && colum[j] < width)
                {
                    //Sum of red, Green, Blue
                    sum_red   += image[row[i]][colum[j]].rgbtRed;
                    sum_green += image[row[i]][colum[j]].rgbtGreen;
                    sum_blue  += image[row[i]][colum[j]].rgbtBlue;
                    count++;
                }
            }
        }
    }
    pixel.rgbtRed = round(sum_red / count);
    pixel.rgbtGreen = round(sum_green / count);
    pixel.rgbtBlue = round(sum_blue / count);
    return pixel;
}