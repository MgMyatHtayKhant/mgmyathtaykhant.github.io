//Header files
#include <cs50.h>
#include <stdio.h>

//Prototype
int get_height(void);

int main(void)
{
    //Get height form user
    int height = get_height();

    //Rows
    for (int i = 0; i < height; i++)
    {
        //Columns are spaces
        for (int j = i + 1; j < height; j++)
        {
            printf(" ");
        }

        //Columns are hash
        for (int h = 0; h <= i; h++)
        {
            printf("#");
        }

        //Two spaces
        printf("  ");

        //Columns are hash
        for (int h = 0; h <= i; h++)
        {
            printf("#");
        }

        //End of row
        printf("\n");
    }

}

int get_height(void)
{
    int n;
    do
    {
        n = get_int("Height: ");
    }
    while (n < 1 || n > 8);
    return n;
}
