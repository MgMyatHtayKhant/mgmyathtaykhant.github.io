from cs50 import get_int


# Define main function


def main():
    num = get_user_input()
    hashtag(num)


# Define user input funtion


def get_user_input():
    while True:
        n = get_int("Height: ")
        if (n > 0 and n < 9):
            break
    return n

# Define hashtag printer function


def hashtag(n):
    for i in range(n):
        print(" " * (n - i - 1), end="")
        print("#" * (i + 1), end="  ")
        print("#" * (i + 1))


# Calling main function
if __name__ == "__main__":
    main()