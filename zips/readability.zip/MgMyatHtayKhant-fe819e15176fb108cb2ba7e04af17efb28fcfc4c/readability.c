#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

//Prototypes
void output(int index);
float average(int w, int a);

int main(void)
{
    //Getting text from user input
    string text = get_string("Text: ");

    //Declare letters, words, sentences
    int zero = 0;
    int letters = zero;
    int words = 1;
    int sentences = zero;
    int n = strlen(text);

    //Counting how many letters, words, sentences from user' text
    for (int i = 0; i < n; i++)
    {
        if (text[i] == '.' || text[i] == '!' || text[i] == '?')
        {
            sentences++;
        }
        else if (isspace(text[i]))
        {
            words++;
        }
        else if (isalpha(text[i]))
        {
            letters++;
        }
    }

    //Finding average letters and sentences
    const float LETTERS = average(words, letters);
    const float SENTENCES = average(words, sentences);

    //the Coleman-Liau index
    int index = round(0.0588 * LETTERS - 0.296 * SENTENCES - 15.8);
    //
    output(index);
}

//Function that print Grade
void output(int index)
{
    //Output of Grade
    if (index >= 16)
    {
        printf("Grade 16+\n");
    }
    else if (index < 1)
    {
        printf("Before Grade 1\n");
    }
    else
    {
        printf("Grade %i\n", index);
    }
}

//Function that get average number of letters or sentences.
float average(int w, int a)
{
    return (100.0 / w) * a;
}