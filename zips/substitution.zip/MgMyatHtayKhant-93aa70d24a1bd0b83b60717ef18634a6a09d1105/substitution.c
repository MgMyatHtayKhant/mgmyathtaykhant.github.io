#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
//Prototypes
bool check_alpha(string a);
bool check_same(string a);
void encipher(string text, string key);

int main(int argc, string argv[])
{
    //Checking argument and validate key
    if (argc != 2)
    {
        printf("Usage: ./substitution key\n");
        return 1;
    }

    //store key from user in another string
    string key = argv[argc - 1];
    //Checking numbers of the key
    if (strlen(key) != 26)
    {
        printf("Key must contain 26 characters.\n");
        return 1;
    }
    //Checking the key is alphabetic or not
    if (check_alpha(key))
    {
        printf("Key must only contain alphabetic characters.\n");
        return 1;
    }
    //Checking the key is repeated or not
    if (check_same(key))
    {
        printf("Key must not contain repeated characters.\n");
        return 1;
    }

    //Get plaintext from user
    string plaintext = get_string("plaintext: ");

    //Calling Substitution cipher
    encipher(plaintext, key);

    //Print ciphertext
    printf("ciphertext: %s\n", plaintext);
}

//Function check for non-alphabetic characters
bool check_alpha(string a)
{
    for (int i = 0, n = strlen(a); i < n; i++)
    {
        if (!isalpha(a[i]))
        {
            return true;
        }
    }
    return false;
}
//Function check for repeated characters
bool check_same(string a)
{
    for (int i = 0, n = strlen(a); i < n; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (a[i] == a[j])
            {
                return true;
            }
        }
    }
    return false;
}
//Substitution cipher
void encipher(string text, string key)
{
    for (int i = 0, n = strlen(text); i < n; i++)
    {
        if (isupper(text[i]))
        {
            text[i] = toupper(key[text[i] - 'A']);
        }
        else if (islower(text[i]))
        {
            text[i] = tolower(key[text[i] - 'a']);
        }

    }
}