l-- Keep a log of any SQL queries you execute as you solve the mystery.

--First, I look up crime scene and see descriptin based on the information that given. I got more info.
 SELECT description FROM crime_scene_reports WHERE day = 28 and month = 7 and year = 2021 and street = "Humphrey Street";

--Based on the info I got, I look up interviews and find 3 witness that mentions the barkery.
SELECT name, transcript FROM interviews WHERE YEAR = 2021 AND month = 7 AND day = 28 AND transcript LIKE "%bakery%";

--Based on Ruth(first witness) interview, I look up bakery security logs. I got 8 suspect names and their info.
SELECT name FROM people WHERE license_plate IN
(SELECT license_plate FROM bakery_security_logs WHERE year = 2021 AND month = 7 AND day = 28 AND hour = 10 AND minute >= 15 AND minute <= 25 AND activity = "exit");

--Based on Eugene (second witness) interview, I look up atm transaction and bank acc Now I got 8 suspect names and their info.
SELECT name FROM people WHERE id
IN ( SELECT person_id FROM bank_accounts WHERE account_number
 IN (SELECT account_number FROM atm_transactions WHERE year = 2021 AND month = 7 AND day = 28
 AND atm_location = "Leggett Street" AND transaction_type = "withdraw"));

--Based on Raymond (third witness) interview, I look up phone calls at that time less than a minute Now I got 8 suspect names and their info.
SELECT name FROM people WHERE phone_number IN
(SELECT caller FROM phone_calls WHERE year = 2021 AND month = 7 AND day = 28 AND duration < 60);

--We have 2 suspect that have common of all characteristic that 3 witness talk.
--They are Bruce and Diana

--Also I look up the earliest flight out of Fiftyville tomorrow. We got the flight id and destination airport id.
SELECT * FROM flights WHERE origin_airport_id = (SELECT id FROM airports WHERE city = "Fiftyville") AND year = 2021 AND month = 7 AND day = 29 AND hour < 9;

--Now We know where the thief went to (New York City)
SELECT * FROM airports WHERE id = 4;

--Now We know who the thief (Bruce)
SELECT * FROM passengers JOIN people ON passengers.passport_number = people.passport_number WHERE flight_id = 36;

--Now We know who the accomplice (Robin)
SELECT * FROM phone_calls WHERE year = 2021 AND month = 7 AND day = 28 AND duration < 60 AND caller = "(367) 555-5533";

SELECT * FROM people WHERE phone_number = "(375) 555-8161";