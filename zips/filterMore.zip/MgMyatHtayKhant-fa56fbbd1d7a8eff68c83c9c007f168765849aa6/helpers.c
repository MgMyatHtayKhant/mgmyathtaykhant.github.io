#include "helpers.h"
#include <math.h>
#define length 3

//Prototypes
RGBTRIPLE box_blur(int r, int c, int height, int width, RGBTRIPLE image[height][width]);
RGBTRIPLE edge_detection(int r, int c, int height, int width, RGBTRIPLE image[height][width]);

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            int average = round((image[i][j].rgbtRed + image[i][j].rgbtGreen + image[i][j].rgbtBlue) / (float)sizeof(RGBTRIPLE));
            image[i][j].rgbtRed = average;
            image[i][j].rgbtGreen = average;
            image[i][j].rgbtBlue = average;
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width / 2; j++)
        {
            RGBTRIPLE pixel = image[i][j];
            image[i][j] = image[i][width - 1 - j];
            image[i][width - 1 - j] = pixel;
        }
    }
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    //Second image
    RGBTRIPLE new_image[height][width];
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            new_image[i][j] = box_blur(i, j, height, width, image);
        }
    }

    //Copying blur pixels from second image to original image
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            image[i][j] = new_image[i][j];
        }
    }
    return;
}

// Detect edges
void edges(int height, int width, RGBTRIPLE image[height][width])
{
    //Second image
    RGBTRIPLE new_image[height][width];
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            new_image[i][j] = edge_detection(i, j, height, width, image);
        }
    }

    //Copying blur pixels from second image to original image
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            image[i][j] = new_image[i][j];
        }
    }
    return;
}

//Kernel convolution
RGBTRIPLE box_blur(int r, int c, int height, int width, RGBTRIPLE image[height][width])
{
    //3 x 3 pixels
    int row[] = {r - 1, r, r + 1};
    int colum[] = {c - 1, c, c + 1};

    RGBTRIPLE pixel;
    float count = 0;
    int sum_red = 0;
    int sum_green = 0;
    int sum_blue = 0;

    //Checking kernel is in between image rows and colums
    for (int i = 0; i < length; i++)
    {
        if (row[i] > -1 && row[i] < height)
        {
            for (int j = 0; j < length; j++)
            {
                if (colum[j] > -1 && colum[j] < width)
                {
                    //Sum of red, green and blue
                    sum_red +=   image[row[i]][colum[j]].rgbtRed;
                    sum_green += image[row[i]][colum[j]].rgbtGreen;
                    sum_blue +=  image[row[i]][colum[j]].rgbtBlue;
                    count++;
                }
            }
        }
    }
    pixel.rgbtRed   = round(sum_red / count);
    pixel.rgbtGreen = round(sum_green / count);
    pixel.rgbtBlue  = round(sum_blue / count);
    return pixel;
}

//Edge Detection
RGBTRIPLE edge_detection(int r, int c, int height, int width, RGBTRIPLE image[height][width])
{
    //3x3 pixels
    int row[]   = {r - 1, r, r + 1};
    int colum[] = {c - 1, c, c + 1};

    //detecting edges in the x direction and y direction
    int gx [length][length] = { {-1, 0, 1}, {-2, 0, 2}, {-1, 0, 1} };
    int gy [length][length] = { {-1, -2, -1}, {0, 0, 0}, {1, 2, 1} };

    RGBTRIPLE pixel;
    int sum_x_red   = 0;
    int sum_x_green = 0;
    int sum_x_blue  = 0;
    int sum_y_red   = 0;
    int sum_y_green = 0;
    int sum_y_blue  = 0;
    
    //Checking kernel is in between image rows and colums
    for (int i = 0; i < length; i++)
    {
        if (row[i] > -1 && row[i] < height)
        {
            for (int j = 0; j < length; j++)
            {
                if (colum[j] > -1 && colum[j] < width)
                {
                    //For x red, green and blue
                    sum_x_red   += (image[row[i]][colum[j]].rgbtRed * gx[i][j]);
                    sum_x_green += (image[row[i]][colum[j]].rgbtGreen * gx[i][j]);
                    sum_x_blue  += (image[row[i]][colum[j]].rgbtBlue * gx[i][j]);
                    
                    //For y red, green and blue
                    sum_y_red   += (image[row[i]][colum[j]].rgbtRed * gy[i][j]);
                    sum_y_green += (image[row[i]][colum[j]].rgbtGreen * gy[i][j]);
                    sum_y_blue  += (image[row[i]][colum[j]].rgbtBlue * gy[i][j]);
                }
            }
        }
    }
    
    //Sobel filter algorithm
    int red   = round(sqrt(pow(sum_x_red, 2) + pow(sum_y_red, 2)));
    int green = round(sqrt(pow(sum_x_green, 2) + pow(sum_y_green, 2)));
    int blue  = round(sqrt(pow(sum_x_blue, 2) + pow(sum_y_blue, 2)));
    
    //Check 0 - 255
    pixel.rgbtRed   = (red > 255) ? 255 : red;
    pixel.rgbtGreen = (green > 255) ? 255 : green;
    pixel.rgbtBlue  = (blue > 255) ? 255 : blue;
    return pixel;
}