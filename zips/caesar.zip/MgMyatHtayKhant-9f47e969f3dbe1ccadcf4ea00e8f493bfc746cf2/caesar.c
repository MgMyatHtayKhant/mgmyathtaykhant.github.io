#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
//Protypes
bool check_digits(string a);
void algorithm(string text, int key);

int main(int argc, string argv[])
{
    //Checking Argument count and Digits at command-line prompt from user.
    if (argc != 2 || check_digits(argv[1]))
    {
        printf("Usage: %s key\n", argv[0]);
        return 1;
    }
    
    //Convert string to int.
    int key = atoi(argv[1]);
    
    //Getting plaintext from user.
    string plaintext = get_string("plaintext: ");
    
    algorithm(plaintext, key);
    
    //Printing ciphertext 
    printf("ciphertext: %s\n", plaintext);
}
//Function of checking digits.
bool check_digits(string a)
{
    for (int i = 0, n = strlen(a); i < n; i++)
    {
        if (!(isdigit(a[i])))
        {
            return true;
        }
    }
    return false;
}
//Caesar’s algorithm function.
void algorithm(string text, int key)
{
    for (int i = 0, n = strlen(text); i < n; i++)
    {   
        if (islower(text[i]))
        {
            text[i] = ((text[i] - 'a' + key) % 26) + 'a';
        }
        else if (isupper(text[i]))
        {
            text[i] = ((text[i] - 'A' + key) % 26) + 'A';
        }
    }
}
