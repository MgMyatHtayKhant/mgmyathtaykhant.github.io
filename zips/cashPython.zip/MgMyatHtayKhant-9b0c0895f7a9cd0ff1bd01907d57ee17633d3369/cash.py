# TODO
from cs50 import get_float

# Define main function


def main():
    # Convert dollars into cents
    cents = round(dollars() * 100)
    number_coins = coins(cents)
    print(f"{number_coins}")

# Define how many change owed function


def dollars():
    while True:
        d = get_float("Change owed: ")
        if d > 0:
            break
    return d

# Define output coins function


def coins(value):
    coins = 0
    quarters = 25
    dimes = 10
    nickels = 5
    pennies = 1
    while value > 0:
        if value >= quarters:
            value -= quarters
        elif value >= dimes:
            value -= dimes
        elif value >= nickels:
            value -= nickels
        else:
            value -= pennies
        coins += 1
    return coins


# Calling main function
if __name__ == "__main__":
    main()