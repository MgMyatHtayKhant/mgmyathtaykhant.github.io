# Get get_int from cs50 library


from cs50 import get_int


# Define main


def main():
    # Get card number from user
    card_number = get_int("Number: ")
    card_number = str(card_number)[::-1]
    card_length = len(card_number)

    last = check_sum(card_length, card_number)
    card_company(last, card_length, card_number)


# Define check sum


def check_sum(card_length, card_number):
    card_sum = 0
    for digit in range(card_length):
        each_digit = int(card_number[digit])
        if digit % 2 != 0:
            digit = each_digit * 2
            card_sum += ((digit % 10) + (digit // 10) if digit > 9 else digit)
        else:
            card_sum += each_digit
    return card_sum


# Define card company


def card_company(last, card_length, card_number):
    credit_digits = [13, 15, 16]
    first_digit = int(card_number[-1])
    second_digit = int(card_number[-2])
    if last % 10 != 0:
        print("INVALID")
    elif not card_length in credit_digits:
        print("INVALID")
    elif first_digit == 4:
        print("VISA")
    elif first_digit == 5 and second_digit in range(1, 6):
        print("MASTERCARD")
    elif first_digit == 3 and second_digit in (4, 7):
        print("AMEX")
    else:
        print("INVALID")


# Check special variable run like main program
if __name__ == "__main__":
    main()