//Header files
#include <cs50.h>
#include <stdio.h>
#include <string.h>


int main(void)
{
    //Get credit card number from user
    long credit_card = get_long("Number: ");

    //Checksum
    int counter = 0;
    int sum = 0;
    int length = 0;
    int a = 0, b = 0; //First two digit
    while (credit_card != 0)
    {
        int last_digit = credit_card % 10;

        //second to last digit
        if (counter % 2 != 0)
        {
            //May be first or second digit
            a = last_digit;

            //Multiply by 2
            last_digit *= 2;

            //if two digit spreat it and add it to sum
            sum += ((last_digit > 9) ? last_digit / 10 + last_digit % 10 : last_digit);
        }
        else
        {
            //May be first or second digit
            b = last_digit;

            //starting from the end
            sum += last_digit;
        }

        counter++;
        length++;
        credit_card /= 10;
    }

    //Set First digit and Second digit
    int first_digit = 0;
    int second_digit = 0;
    if (length == 16)
    {
        first_digit = a;
        second_digit = b;
    }
    else
    {
        first_digit = b;
        second_digit = a;
    }

    //Check for card length and starting digits
    if (length != 13 && length !=  15 && length != 16)
    {
        printf("INVALID\n");
    }
    else if (sum % 10 != 0)
    {
        printf("INVALID\n");
    }
    else if (first_digit == 3 && (second_digit == 4 || second_digit == 7))
    {
        printf("AMEX\n");
    }
    else if (first_digit == 5 && second_digit > 0 && second_digit < 6)
    {
        printf("MASTERCARD\n");
    }
    else if (first_digit == 4)
    {
        printf("VISA\n");
    }
    else
    {
        printf("INVALID\n");
    }

}
